This game was made in a week. Due to that I did not have time to make a proper tutorial so
I'll tell you how to play in this file.

The goal of the game is to kill all the enemies and reach the end of the level.

IMPORTANT: When you die the game will not automatically respawn you. You must press R
to respawn from the last checkpoint. Alternatively press ESC to bring up the pause menu.
On the pause menu you can click a button to respawn from the last checkpoint or click a
button to respawn at the beginning of the level. You can also press ESC again to close the
pause menu.

A - move left
D - move right
W - jump
Space - jump
Left Click - shoot towards cursor
Right Click - grapple nearest object in direction of cursor

You do not need to hold down right click to grapple. Press it once to grapple, and press
it again to release.

You can use the recoil of the gun to propel yourself if you are not on the ground.
I recommend using this to build up speed while swinging from the grappling hook.