Don't run the game from the zip file. Drag this folder out onto you Desktop, Documents, or
wherever you want. Also make sure to read the other README file which contains the 
controls to the game.